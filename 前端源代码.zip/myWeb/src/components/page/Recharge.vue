<template>
    <div class="">
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-lx-recharge"></i> 收款二维码</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <el-upload 
                class="upload-demo"
                drag
                action="https://upload.qiniup.com"
                :data='upData'
                :before-upload="beforeAvatarUpload"
                :on-success="upSuccess">
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                <div class="el-upload__tip" slot="tip">只能上传jpg/png/jpge文件，且不超过2MB</div>
            </el-upload>
            <!-- 二维码展示 -->
            <template>
                <el-table
                    :data="qrCode"
                    style="width: 100%"
                    :row-class-name="tableRowClassName">
                    <el-table-column
                    prop="type"
                    label="收款方式"
                    width="180"
                    :filters="[{ text: '微信', value: 'alipay' }, { text: '支付宝', value: 'wechat' }]"
                    :filter-method="filterTag">
                    </el-table-column>
                    <el-table-column
                    prop="price"
                    label="金额"
                    width="180">
                    </el-table-column>
                    <el-table-column
                    prop="pay_url"
                    label="支付url"
                    width="300">
                    </el-table-column>
                    <el-table-column
                    prop="status"
                    label="使用中"
                    width="180"
                    >
                    </el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </template>
            <!-- 分页 -->
            <el-pagination
                background
                :total="page.total"
                :pageSize="10"
                @current-change="nextPage">
            </el-pagination>
        </div>
        
    </div>
</template>

<script>
    export default {
        name: 'recharge',
        data() {
            return {
               upData: {
                   token: '',
                   key: ''
               },
               page: {
                   page: 1,
                   num: 10,
                   total: 0
               },
               qrCode: []
            }
        },
        mounted () {
            this.upqiniu()
            this.getQrList()
        },
        methods: {
            handleDelete (index, row) { // 删除
                let that = this
                that.$confirm('确定删除此收款二维码?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(async () => {
                    let result = await that.delQrCode(row.id)
                    if (result == '删除成功!') {
                        that.$message({
                            type: 'success',
                            message: result
                        });
                        that.getQrList()
                    } else {
                        that.$message({
                            type: 'error',
                            message: result
                        });
                    }
                    
                }).catch(() => {
                    that.$message({
                        type: 'info',
                        message: '已取消删除'
                    });          
                });
            },
            delQrCode (id) {
                return new Promise(async (res, rej) => {
                    this.$axios({
                        url: '/api/qrcodedel',
                        method: 'delete',
                        data: {
                            id: id
                        }
                    }).then(result => {
                        res(result.data.msg)
                    })
                })
            },
            nextPage (val) {
                this.page.page = val;
                this.getQrList()
            },
            filterTag (value, row, column) {
                const property = column['property'];
                return row[property] === value;
            },
            tableRowClassName({row,status}) {
                if (row.status == 1) { // 二维已经绑定
                    return 'warning-row';
                } else if (row.status == 0) { // 二维码未绑定订单
                    return 'success-row';
                }
                    return '';
            },
            upqiniu (e) {
                let self = this
                self.$axios({
                    url: '/api/updata',
                    method: 'post',
                }).then(res  => {
                    if (res.data.code == -1) {
                         this.$message.error(res.data.msg);
                         return false
                    } else {
                        self.upData.token = res.data.data.toKen
                    }
                })
            },
            getQrList () {
                this.$axios({
                    url: '/api/qrcodeall',
                    method: 'get',
                    params: {
                        page: this.page.page,
                        num: this.page.num
                    }
                }).then(res => {
                    if (res.data.code == -1) {
                        this.$message.error(res.data.msg)
                        return false
                    }
                    this.qrCode = res.data.data.rows
                    this.page.total = res.data.data.count
                })
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg' || file.type === 'image/png' || file.type === 'image/jpg';
                const isLt2M = file.size / 1024 / 1024 < 2;
                if (!isJPG) {
                this.$message.error('上传图片只能是 JPG /PNG / JPEG格式!');
                }
                if (!isLt2M) {
                this.$message.error('上传图片图片大小不能超过 2MB!');
                }
                this.upData.key = + new Date() + '.' + file.type.substring(6); // 更改上传图片名称
                return isJPG && isLt2M;
            },
            handleRead(index) {
                const item = this.unread.splice(index, 1);
                console.log(item);
                this.read = item.concat(this.read);
            },
            handleDel(index) {
                const item = this.read.splice(index, 1);
                this.recycle = item.concat(this.recycle);
            },
            handleRestore(index) {
                const item = this.recycle.splice(index, 1);
                this.read = item.concat(this.read);
            },
            upSuccess (response, file, fileList) { // 图片上传成功
                let staticUrl = this.$staticUrl
                this.getQrContent(staticUrl + file.response.key)
            },
            getQrContent (url) {
                let self = this
                self.$axios({
                    url: '/api/qrcodeadd',
                    method: 'post',
                    data: {url: url}
                }).then(res => {
                    if (res.data.code == -1) {
                        this.$message.error(res.data.msg)
                        return false
                    } else {
                        this.$message.success(res.data.msg)
                        this.getQrList()
                    }
                })
            }
        },
        computed: {
            unreadNum(){
                return this.unread.length;
            }
        }
    }

</script>

<style>
.message-title{
    cursor: pointer;
}
.handle-row{
    margin-top: 30px;
}
.el-table .warning-row {
    background: oldlace;
}

.el-table .success-row {
    background: #f0f9eb;
}
</style>

