<template>
    <div>
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-lx-goods"></i> 添加商品</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="plugins-tips">
               <el-input v-model="goodsName" placeholder="请输入商品名称" maxlength="50"></el-input>
            </div>
            <div class="plugins-tips">
               <el-input-number v-model="price" :min="1" :max="1999" :step="0.1" :precision="2" label="描述文字"></el-input-number>
            </div>
            <div class="plugins-tips">
               <el-input v-model="goodsKey" placeholder="自动发货内容" ></el-input>
            </div>
            <quill-editor ref="myTextEditor" v-model="content" :options="editorOption"></quill-editor>
            <el-button class="editor-btn" type="primary" @click="submit">发布商品</el-button>
        </div>
    </div>
</template>

<script>
    import 'quill/dist/quill.core.css';
    import 'quill/dist/quill.snow.css';
    import 'quill/dist/quill.bubble.css';
    import {quillEditor, Quill} from 'vue-quill-editor'
    import {container, ImageExtend, QuillWatch} from 'quill-image-extend-module'
    Quill.register('modules/ImageExtend', ImageExtend)
    export default {
        name: 'editor',
        data: function(){
            return {
                content: '',
                goodsKey: '',
                upData: {
                   token: '',
                   key: ''
               },
                editorOption: {
                    placeholder: '请输入商品描述',
                    modules:{
                        ImageExtend: {
                            loading: true,
                            name: 'file',
                            action: 'https://upload.qiniup.com',
                            size: 2, 
                            change: (xhr, formData) => {
                                formData.append('token', this.upData.token)
                                formData.append('key', + new Date() + '.png')
                            }, 
                            response: (res) => {
                                let staticUrl = this.$staticUrl
                                return staticUrl + res.key
                            }
                        },
                        toolbar: {  // 如果不上传图片到服务器，此处不必配置
                             container: [
                                ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
                                ['blockquote', 'code-block'],

                            // [{ 'header': 1 }, { 'header': 2 }],               // custom button values
                            // [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                            // [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
                                [{ 'indent': '-1'}, { 'indent': '+1' }],          // outdent/indent
                                //[{ 'direction': 'rtl' }],                         // text direction

                                //[{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
                                //[{ 'header': [1, 2, 3, 4, 5, 6, false] }],

                                [{ 'color': [] }, { 'background': [] }],          // dropdown with defaults from theme
                                ['image'],
                                //[{ 'font': [] }],
                                //[{ 'align': [] }],
                                ['clean']                  
                            ],  // container为工具栏，此次引入了全部工具栏，也可自行配置
                            handlers: {
                                'image': function () {  // 劫持原来的图片点击按钮事件
                                    QuillWatch.emit(this.quill.id)
                                }
                            }
                        },
                    }
                },
                goodsName: '',
                price: 1
            }
        },
        components: {
            quillEditor
        },
        mounted () {
            this.upqiniu()
        },
        methods: {
            upqiniu (e) { // 获取上传图片的token
                let self = this
                self.$axios({
                    url: '/api/updata',
                    method: 'post',
                }).then(res  => {
                    if (res.data.code == -1) {
                         this.$message.error(res.data.msg);
                         return false
                    } else {
                        self.upData.token = res.data.data.toKen
                    }
                })
            },
            onEditorChange({ editor, html, text }) {
                this.content = html;
            },
            submit(){
                let that = this;
                that.$axios({
                    url: '/api/goodadd',
                    method: 'post',
                    data: {
                        goods_name: that.goodsName,
                        price: that.price,
                        content: that.content,
                        goodsKey: that.goodsKey
                    }
                }).then(res => {
                    if (res.data.code != -1) {
                        that.$message.success(res.data.msg);
                        that.goodsName = ''
                        that.price = 1.00
                        that.content = ''
                        return false
                    }
                    that.$message.error(res.data.msg);
                })
                
            },
            beforeUpload(file) { // 图片上传的钩子
            // return this.qnUpload(file)
                console.log(file)
            },
        }
    }
</script>
<style scoped>
    .editor-btn{
        margin-top: 20px;
    }
</style>