<template>
    <div class="table">
        <div class="crumbs">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="el-icon-lx-cascades"></i> 订单管理</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="container">
            <div class="handle-box">
                <el-select v-model="pay_type" placeholder="支付方式" class="handle-select mr10">
                    <el-option key="1" label="支付宝" value="alipay"></el-option>
                    <el-option key="2" label="微信" value="wechat"></el-option>
                </el-select>
                 <el-select v-model="pay_status" placeholder="支付状态" class="handle-select mr10">
                    <el-option key="1" label="已支付" value="ok"></el-option>
                    <el-option key="2" label="未支付" value="no"></el-option>
                </el-select>
                <el-input v-model="pay_orderId" placeholder="订单号" class="handle-input mr10"></el-input>
                <el-button type="primary" icon="search" @click="search">搜索</el-button>
            </div>
            <el-table :data="data" border class="table" ref="multipleTable" >
                <el-table-column prop="createdAt" label="订单时间" sortable width="180">
                </el-table-column>
                <el-table-column prop="order_id" label="订单号" width="200">
                </el-table-column>
                <el-table-column prop="goods_name" label="商品名称">
                </el-table-column>
                 <el-table-column prop="price" label="订单金额" >
                </el-table-column>
                <el-table-column prop="pay_price" label="支付金额" >
                </el-table-column>
                <el-table-column prop="pay_type" label="支付方式" >
                </el-table-column>
                <el-table-column prop="status" label="支付状态" >
                </el-table-column>
            </el-table>
            <div class="pagination">
                <el-pagination background @current-change="handleCurrentChange" layout="prev, pager, next" :total="total">
                </el-pagination>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'basetable',
        data() {
            return {
                pay_type: '',
                pay_status: '',
                pay_orderId: '',
                is_search: false,
                total: 0,
                data:[],
                page: 1,
                num: 10,
            }
        },
        created() {
            this.getData()
        },
        methods: {
            // 搜索
            search () {
                this.is_search = true;
                this.page = 1;
                this.getData()
            },
            // 分页导航
            handleCurrentChange(val) {
                this.page = val;
                this.getData();
            },
            // 获取 easy-mock 的模拟数据
            getData() {
                let that = this
                that.$axios({
                    url: '/api/getfindorder',
                    method: 'get',
                    params: {
                        page: that.page,
                        num: that.num,
                        pay_type: that.pay_type,
                        status: that.pay_status,
                        order_id: that.pay_orderId
                    }
                }).then(res => {
                    if (res.data.code != -1) {
                        that.data = res.data.data.rows
                        that.total = res.data.data.count
                    }
                })
            },
        }
    }

</script>

<style scoped>
    .handle-box {
        margin-bottom: 20px;
    }

    .handle-select {
        width: 120px;
    }

    .handle-input {
        width: 300px;
        display: inline-block;
    }
    .del-dialog-cnt{
        font-size: 16px;
        text-align: center
    }
    .table{
        width: 100%;
        font-size: 14px;
    }
    .red{
        color: #ff0000;
    }
</style>
