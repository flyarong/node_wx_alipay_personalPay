<template>
    <el-container style="max-width:750px;margin:0 auto;" v-if="show">
        <el-header>
            {{goodsData.goods_name}}
        </el-header>
        <el-main style="padding-top:0px">
            <el-tag style="margin-bottom:10px">价格￥{{goodsData.price}}</el-tag>
            <el-tag type="danger">随机减免</el-tag>
            <div v-html="goodsData.content"></div>
        </el-main>
        <el-footer>
            <span @click="pop()" style="width:100%;display: inline-block;font-size: 1.5em;font-weight: 400;">立即购买</span>
        </el-footer>
        <el-dialog
            title="请选择支付方式"
            :visible.sync="centerDialogVisible"
            width="80%"
            center>
            <el-switch
                style="display: block"
                v-model="pay_type"
                active-color="#13ce66"
                inactive-color="#00a9f9"
                active-text="微信支付"
                inactive-text="支付宝支付">
            </el-switch>
            <span slot="footer" class="dialog-footer">
                <el-button @click="centerDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="pay();centerDialogVisible = false">确 定</el-button>
            </span>
        </el-dialog>
    </el-container>
</template>

<script>
    export default {
        data () {
            return {
                goodsData: [],
                nanoid: this.$route.params.id,
                show: false,
                email: '',
                pay_type: false, // 支付方式 false = 支付宝 true 微信
                centerDialogVisible: false,
            }
        },
        mounted () {
            this.findOne()
        },
        methods: {
            findOne () {
                let that = this;
                that.$axios({
                    url: '/api/goodsfindone',
                    method: 'get',
                    params: {
                        nanoid: that.nanoid
                    }
                }).then(res => {
                    if (res.data.code == -1) {
                        that.$message.error(res.data.msg)
                        that.show = false
                    } else {
                        that.goodsData = res.data.data
                        document.title = res.data.data.goods_name + '--让支付变简单点'
                        that.show = true
                    }
                })
            },
            pop () {
                let that = this
                that.$prompt('请输入邮箱，接收商品。', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    inputPattern: /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/,
                    inputErrorMessage: '邮箱格式不正确'
                }).then(({ value }) => {
                    that.email = value
                    that.centerDialogVisible = true
                }).catch(() => {
                    that.$message({
                        type: 'info',
                        message: '取消购买'
                    });       
                });
            },
            pay () {
                let that = this
                that.$axios({
                    url: '/api/orderadd',
                    method: 'post',
                    data: {
                        nanoid: that.nanoid,
                        email: that.email,
                        pay_type: that.pay_type == false ? 'alipay' : 'wechat'
                    }
                }).then(res => {
                    if (res.data.code != -1) {
                        that.$message({
                            type: 'success',
                            message: res.data.msg
                        });
                        that.$router.push('/pay/' + res.data.data.order_id)
                    } else {
                        that.$message({
                            type: 'info',
                            message: res.data.msg
                        });    
                    }
                })
            }
        },
        watch: {
            '$route' (to,from) {
                this.nanoid = to.params.id
                this.findOne()
            }
        }
    }
</script>

<style>
    img{
        max-width: 100%;
    }
    .el-footer{
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background: #67C23A;
        text-align: center;
        line-height: 60px;
        color: #fff;
    }
    .el-header {
        min-height: 22px;
        line-height: 22px;
        padding: 10px 20px;
    }
    .el-message-box{
        width: 80% !important;
    }
</style>