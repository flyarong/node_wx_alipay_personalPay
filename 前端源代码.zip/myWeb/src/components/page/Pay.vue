<template>
    <div class="container" v-show="mainShow">
        <div class="header">
            <div :class="[{'logowechat': orderData.pay_type == 'wechat', 'logo': orderData.pay_type == 'alipay'}]"></div>
        </div>
        <div class="mainbody">
            <div class="realprice">￥{{orderData.pay_price}}</div>
            <div class="discountprice" v-show="orderData.price != orderData.pay_price"><del>原价:￥{{orderData.price}}</del>，随机立减:￥{{ Math.floor((orderData.price - orderData.pay_price) * 100) / 100 }}</div>
            <!-- <div class="warning" v-show="isWeixin == false && orderData.pay_type == 'alipay'">长按识别后,请务必手动输入金额￥{{orderData.pay_price}}</div> -->
            <div class="qrcode" >
                <div id="img" class="image"></div>
                <div :class="['logo',{'logologo-alipay': orderData.pay_type == 'alipay','hidden-xs':true}]"></div>
                <div :class="['expired',{'hidden': expired == true}]"></div>
                <div :class="['paid', {'hidden': pay_ok == false}]"></div>
            </div>
            <div class="remainseconds">
                <div class="time minutes">
                    <b>{{minutes}}</b>
                    <em>分</em>
                </div>
                <div class="colon">:</div>
                <div class="time seconds">
                    <b>{{seconds}}</b>
                    <em>秒</em>
                </div>
            </div>

            <div class="tips">
                <div v-if="device == 'mobile'">
                    <div v-if="orderData.pay_type != 'alipay'">
                        <div v-if="isWeixin == true">请长按二维码进行支付</div>
                        <div v-else>请截屏后打开{{orderData.pay_type != 'alipay' ?'微信' : '支付宝'}},从相册选择二维码图片</div>
                    </div>
                    <div v-else>
                         <div v-if="isWeixin == false">请截屏后，打开{{orderData.pay_type != 'alipay' ?'微信' : '支付宝'}}，从相册选择二维码图片</div>
                         <div v-else>
                             <a :href="orderData.pay_url" class="btn btn-info btn-lg">启动{{orderData.pay_type != 'alipay' ?'微信' : '支付宝'}}进行支付</a>
                         </div>
                    </div>
                </div>
                <div v-else>
                    打开{{orderData.pay_type != 'alipay' ?'微信' : '支付宝'}}「扫一扫」
                </div>
            </div>
        </div>
    </div>
</template>

<script scoped>
export default {
    data () {
        return {
            order_id: this.$route.params.orderid,
            orderData: [],
            minutes: 0,
            seconds: 0,
            mainShow: false,
            timer: '',
            expired: true,
            device: 'mobile',
            isWeixin: false,
            pay_status: '',
            pay_ok: false
        }
    },
    mounted () {
        this.getOrder()
        // 检测运行环境
        if ((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
            this.device = 'mobile'
            let ua = navigator.userAgent.toLowerCase();
            this.isWeixin = ua.indexOf('micromessenger') != -1;
        }else{
            this.device = 'PC'
        }
        this.init()
    },
    methods: {
        init () {
            // 检查支付状态
            let that = this
            that.pay_status = setInterval(that.getPayStatus,2000)
        },
        getPayStatus () {
            let that = this
            that.$axios({
                url: '/api/orderstatus',
                method: 'get',
                params: {
                    order_id: that.order_id
                }
            }).then(res => {
                if (res.data.code == -1) {
                    that.$message({
                        type: 'info',
                        message: res.data.msg
                    });
                    clearInterval(that.pay_status)
                } else {
                    if (res.data.data.status == 'ok') {
                        clearInterval(that.pay_status)
                        clearInterval(that.timer);
                        that.pay_ok = true
                    }
                }
            })
        },
        time (maxtime) { 
            let that = this
            let times = maxtime
            that.timer = setInterval(() => {
                if (times >= 0) {
                    that.minutes = Math.floor(times / 60) < 10 ? '0' + Math.floor(times / 60) : Math.floor(times / 60);
                    that.seconds = Math.floor(times % 60) < 10 ? '0' +  Math.floor(times % 60) : Math.floor(times % 60);
                    --times
                } else{
                    that.expired = false
                    clearInterval(that.timer);
                    clearInterval(that.pay_status)
                }
            }, 1000);  
        },
        getOrder () {
            let that = this
            that.$axios({
                url: '/api/getorderid',
                method: 'get',
                params: {
                    order_id: that.order_id
                }
            }).then(res => {
                if (res.data.code == -1) {
                    that.$message({
                        type: 'info',
                        message: res.data.msg
                    });
                } else {
                    that.orderData = res.data.data
                    this.mainShow = true
                    // 计算时间
                    this.time(res.data.time / 1000)
                    let qrcode = new QRCode("img", {
                        text: res.data.data.pay_url,
                        width: 200,
                        height: 200,
                        colorDark : "#000000",
                        colorLight : "#ffffff",
                        correctLevel : QRCode.CorrectLevel.H
                    });
                }
            })
        }
    },
    watch: {
        '$route' (to,from) {
            let that = this
            this.order_id = to.params.orderid
            this.getOrder()
            clearInterval(that.timer);
            clearInterval(that.pay_status)
        }
    }
}
</script>

<style src='../../assets/css/bootstrap.min.css' scoped></style>
<style src='../../assets/css/pay.css' scoped></style>
<style>
#img>img{
  width: 100% !important;
}
</style>



